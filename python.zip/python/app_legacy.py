from uiautomator import device as d
import json
import time

true = True
false = False

class AiMapsError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)

#--------------IAMTHEMAP-----------
_Map = []
#--------------IAMTHEMAP-----------

def Click(obj):
    obj = obj.info
    _t = obj["visibleBounds"]["top"]
    _b = obj["visibleBounds"]["bottom"]
    _l = obj["visibleBounds"]["left"]
    _r = obj["visibleBounds"]["right"]
    d.click((_l + ((_r - _l) / 2)),(_t + ((_b - _t) / 2)))

def Run(str):
    ua = understandAction(str)
    rs = json.dumps(searchActions(ua))
    AiMaps = d(text=rs).aimaps

    if (AiMaps == False) :
        raise AiMapsError('No se ejecuto correctamente la prueba en AiMaps')
    return AiMaps

def TryRun(str):
    ua = understandAction(str)
    rs = json.dumps(searchActions(ua))
    AiMaps = d(text=rs).aimaps
    return AiMaps    

def understandAction(str):
    sa = str.split(">")
    if(len(sa)>0):
        return sa
    else:
        return []

def findAll(str):
    ua = understandAction(str)
    obj = searchActions(ua)
    if (len(obj)>0):
        actionFind = obj[0]["actions"][0]
        if (actionFind["action"] == "DomFindAll"):
            EltFind = json.loads(actionFind["value"])[0]
            if (EltFind["name"] == "text"):
                return d(text=EltFind["value"])
            if (EltFind["name"] == "textContains"):
                return d(textContains=EltFind["value"])
    return []

def searchActions(arr):
    if (len(arr)>0):
        for step in _Map:
            if (step["nameStep"] == arr[0]) :
                if (len(arr)>1):
                    for action in step["actions"] :
                        if (action["name"] == arr[1]):
                            actionTem = [action]
                            step["actions"] = actionTem
                return [step]
    return []

def Sleep(num):
    time.sleep(num)

#--------------REPLACEME-----------
def Execute(): 
    return True
#--------------REPLACEME-----------

try:
    Exec = Execute()
except AiMapsError:
    Exec = False


if (Exec != None and Exec == True) :
    print "||-true||-"

if (Exec == None or Exec == False) :
    print "||-false||-"    